%%
I = im2double(imread('test.tiff')); 

%%
[ ~, bg ] = correct_illum( I, 30, 40, 0.05, 3 ); 

%%
Ic = I ./ bg ./ 2; 
figure; subplot(221); imshow(I); title('before calib'); 
subplot(222); imshow(bg); title('background extracted'); 
subplot(212); imshow(Ic); title('after calib'); 
