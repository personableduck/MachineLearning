%%
I = im2double(imread('test.tiff')); 

%%
wl = 'sym4';
N = 5;
[CMono, SMono] = wavedec2(I, N, wl);
tmp = CMono(SMono(1,1)*SMono(1,2)+1:end); 
CMono(SMono(1,1)*SMono(1,2)+1:end) = zeros(size(tmp)); 
bg = waverec2(CMono, SMono, wl); 

%%
Ic = I ./ bg ./ 2; 
figure; subplot(221); imshow(I); title('before calib'); 
subplot(222); imshow(bg); title('background extracted'); 
subplot(212); imshow(Ic); title('after calib'); 

%% NOTES FOR DEVELOPER: TRY VARYING N TO COMPARE RESULTS; CURRENTLY N NOT SYSTEMATICALLY OPTIMIZED