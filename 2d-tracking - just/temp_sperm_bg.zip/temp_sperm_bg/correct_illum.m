function [ B, I ] = correct_illum( A, num_row, num_col, thr, downsp )

if ~isempty(downsp), 
    A1 = imresize(A, 1/downsp); 
else
    A1 = A; 
end

I = zeros(size(A1)); 

for ii = 1: num_row, 
    for jj = 1: num_col, 
        cur_v = [floor(size(A1,1)/num_row*(ii-1))+1, ceil(size(A1,1)/num_row*ii)];
        cur_h = [floor(size(A1,2)/num_col*(jj-1))+1, ceil(size(A1,2)/num_col*jj)];
        cur_tile = A1(cur_v(1): min(cur_v(2), end), cur_h(1): min(cur_h(2), end)); 
        a = cur_tile(:); 
        for kk = 1: 10, 
            m_a = mean(a(:)); 
            a(abs(a-m_a)>thr) = []; 
        end
        I(cur_v(1): cur_v(2), cur_h(1): cur_h(2)) = ones(cur_v(2)-cur_v(1)+1,cur_h(2)-cur_h(1)+1) * m_a; 
    end
end

I_lr = fliplr(I); 
I_ud = flipud(I); 
I_iv = flipud(I_lr); 

I_tmp = [I_iv, I_ud, I_iv; I_lr, I, I_lr; I_iv, I_ud, I_iv]; 

h = fspecial('gaussian', 3*[cur_v(2)-cur_v(1)+1, cur_h(2)-cur_h(1)+1], min(cur_v(2)-cur_v(1)+1, cur_h(2)-cur_h(1)+1)); 
I = imfilter(I_tmp, h); 

I = I(size(I_lr, 1)+1: 2*size(I_lr, 1), size(I_lr,2)+1: 2*size(I_lr,2)); 

if ~isempty(downsp), 
    I = imresize(I, [size(A,1), size(A,2)]); 
else
end

B = A ./ I; 

end

